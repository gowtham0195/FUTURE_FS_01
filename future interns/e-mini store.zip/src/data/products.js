export const products = [
  {
    id: 1,
    name: "Mini T-shirt",
    price: 19.99,
    image: "https://via.placeholder.com/150",
  },
  {
    id: 2,
    name: "Mini Shoes",
    price: 49.99,
    image: "https://via.placeholder.com/150",
  },
];
